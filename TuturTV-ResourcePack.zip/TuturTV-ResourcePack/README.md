# TuturTV Resource Pack

Ce pack utilise directement le logo fourni `download.png`. Le fichier `assets/minecraft/font/tutur_logo.png` est une version redimensionnée sans déformation pour un affichage TAB de 16 pixels de haut. `pack.png` utilise le fichier logo original comme icône du pack.

Minecraft Java 1.21.11 utilise la version de resource pack `75.0`. Le `pack.mcmeta` utilise les champs modernes `min_format` et `max_format` avec `[75, 0]`.

## Installation

1. Copier le dossier `TuturTV-ResourcePack` dans `.minecraft/resourcepacks`, ou créer une archive ZIP dont `pack.mcmeta` est à la racine.
2. Activer le pack dans Minecraft.
3. Vérifier qu'il apparaît sans avertissement d'incompatibilité.
4. Installer la configuration TAB fournie dans le dossier `TAB`, puis exécuter `/tab reload`.

## Test

Avec le pack activé, exécuter :

```mcfunction
/tellraw @s {"text":"\uE000","font":"minecraft:tutur"}
```

Le logo doit apparaître. Sans le pack, U+E000 affichera le glyphe manquant du client, mais le serveur et les autres textes continueront de fonctionner.

Le fichier `default.json` ajoute le bitmap puis référence les providers vanilla inclus, afin de conserver les lettres, chiffres, accents et symboles normaux. `tutur.json` est utilisé par TAB et est la variante recommandée.
